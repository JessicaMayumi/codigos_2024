#include <iostream>
using namespace std;

int main() {
   cout << "Hello World";
   return 0;
}

// https://sceweb.sce.uhcl.edu/helm/WEBPAGE-Cpp/my_files/TableContents/Module-3/module3page.html

// https://sceweb.sce.uhcl.edu/helm/WEBPAGE-Cpp/

/*

$ g++ hello.cpp
$ ./a.out
Hello World

*/