package reflexao;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

//anotação disponível em tempo de execução
@Retention(RetentionPolicy.RUNTIME)
public @interface Metadado2 {
}