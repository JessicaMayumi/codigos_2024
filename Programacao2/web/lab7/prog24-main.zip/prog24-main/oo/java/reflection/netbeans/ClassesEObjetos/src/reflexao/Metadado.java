package reflexao;

//anotação básica
public @interface Metadado {
}