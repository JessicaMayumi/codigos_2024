# definir o número
n = 5
# inicializa um acumulador em 1

# fazer uma repetição de 1 até n mais 1

    # multiplica no acumulador o índice da repetição

# mostra o acumulado